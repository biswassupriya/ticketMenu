//Supriya Biswas
//Assement
//7/11/2018
public class Ticket {
	//declare variables
	private String fName;
	private String lName;
	private String address;
	private double studDiscount;
	private double childDiscount;
	private double fee;
	private double ticketprice1;
	private double ticketprice2;
	private double discount1;
	private double discount2;
	

      //constructor - set fee to a default zero
     public Ticket()
    { // initialises class variables
    	  fName = "";
    	  lName = "";
    	  address = "";
    	  studDiscount = 0; // set zero
    	  childDiscount = 0; // set zero
    	  fee = 50; // fee set 50
    	  ticketprice1 = 0; // set zero
    	  ticketprice2 = 0; // set zero
    	  discount1 = 0;  // set zero
    	  discount2 =0;  // set zero
    }
     
     // setters for fName
     public void SetfName(String name)
 	{
 		fName = name;
 	}
     
     // setters for lName
     public void SetlName(String name)
     {
    	 lName = name;
     }
     
     // setters for address
     public void Setaddress(String add)
     {
    	 address = add;
     }
     
     // setters for studDiscount
     public void SetstudDiscount(boolean student)
     { // set the student
    	if(student == true)
    	{
    	 studDiscount = 15;
    	}
    	else
    	{
    	 studDiscount = 0;
    	}
     }
     
     //setter for childDiscount
     public void SetchildDiscount(boolean child)
     {
    	 if(child == true)
    	 {
    		 childDiscount = 25;
    	 }
    	 else
    	 {
    		childDiscount = 0; 
    	 }
     }
     
     //setter for ticketprice1
     public void Setticketprice1()
     {
    	 discount1 = fee*studDiscount/100;
    	 ticketprice1 = fee-discount1;
     }
     
     //setter for ticketprice2
     public void Setticketprice2()
     {
    	 discount2 = fee*childDiscount/100;
    	 ticketprice2 = fee-discount2;
     }
     
     
     // getter for the fName
     public String getfName()
     {
    	 return fName;
     }
     
     // getter for lName
     public String getlName()
     {
    	 return lName;
     }
     
     // getter for address
     public String getaddress()
     {
    	 return address;
     }
     
     // getter for fee
     public double getfee()
     {
    	 return fee;
     }
     
     // getter for ticketprice1
     public double getticketprice1()
     {
    	 return ticketprice1;
     }
     
     // getter for ticketprice2
     public double getticketprice2()
     {
    	 return ticketprice2;
     }
     
     //getter for discount1
     public double getdiscount1()
     {
    	 return studDiscount;
     }
     
    // getter for discount2
     public double getdiscount2()
     {
    	 return childDiscount;
     }


     //getter for discount1
     public double getdiscounta()
     {
    	 return discount1;
     }
     
    // getter for discount2
     public double getdiscountb()
     {
    	 return discount2;
     }
	}

     
     
     
    	  
    	  
    	  
    	  

	
	
	
	
	



   
   
 


