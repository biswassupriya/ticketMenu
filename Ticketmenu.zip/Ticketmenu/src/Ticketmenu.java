// supriya biswas
//7/11/2018
//assement
import java.util.Scanner;
public class Ticketmenu {

	public static void main(String[] args) {
		// declare variables
		int option = 0;
		boolean student;
		boolean child;
		
	Scanner sc = new Scanner(System.in);
	
	Ticket myticket = new Ticket(); // an object myticket is for the class Ticket
	
	// menu quit when 4 selected
	while (option !=4)
	{
		System.out.println("Menu");
		System.out.println("1-Calculate student discount Rate:");
		System.out.println("2-Calculate child discount Rate:");
		System.out.println("3-Display ticket details:");
		System.out.println("4-Exit Menu:");
		System.out.println("Enter option: ");
		
		option = sc.nextInt(); //input option
		
		// validate a correct option entered
		while (option<1||option>4)
		{
			if(option<1||option>4)
			{
				System.out.println("invalid-enter 1-4");
			}
			System.out.println("Enter option:");
			option = sc.nextInt();
		}
	
	  //switch / case statements to carry out operations
	   switch(option)
	   {
	   case 1: System.out.print("Are you a student true or false: ");
	   		   student = sc.nextBoolean();
	           myticket.SetstudDiscount(student);
	   
	           System.out.println("Student discount rate: " + myticket.getdiscount1() + "\n");
	           break;
	           
		   
	   case 2: System.out.print("Are you a child under 16years true or false:");
	           child = sc.nextBoolean();
	           myticket.SetchildDiscount(child);
	           
	           System.out.print("child discount rate:" + myticket.getdiscount2() + "\n");
	           break;
	      
	   case 3:  System.out.println("Enter First Name:");
               myticket.SetfName(sc.next()); // use setters to receive input
       
               System.out.println("Enter Last Name:");
               myticket.SetlName(sc.next());

               System.out.println("address:");
               myticket.Setaddress(sc.next());
               
               myticket.Setticketprice1(); // set fees for student
               
               myticket.Setticketprice2(); // set fees for child
               
               System.out.println("Your Details : " + myticket.getfName()+" "+myticket.getlName()+" "+myticket.getaddress());
                  
               System.out.println("Normal fee with no discount are �" + myticket.getfee());
	                                   
               //use the getters to retrieve the data from myticket
		       System.out.println("Student Discount = �" + myticket.getdiscounta() + " Student Total Fee Due �" +myticket.getticketprice1());
		       
		       
		       System.out.println("Child Discount = �" + myticket.getdiscountb() + "child total fee due �" + myticket.getticketprice2());
		      
		       System.out.println("Normal fees with Discount rate are");
                  break;
               
	   case 4: sc.close();//close the scanner
	           break;
               
	   } // switch
	}// while
	}// main
}//class
	
	